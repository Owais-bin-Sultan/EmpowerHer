import React, { useState, useEffect } from 'react';
import { Button } from "../components/CustomUI";
import { Card, CardContent, CardHeader, CardTitle } from "../components/CustomUI";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/CustomUI";
import { Badge } from "../components/CustomUI";
import { CheckCircle, XCircle } from 'lucide-react';
import axios from 'axios';

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      console.log('Fetching users...');
      setLoading(true);
      const response = await axios.get('http://localhost:5000/api/admin/users');
      console.log('Users fetched:', response.data);
      setUsers(response.data);
      setError(null);
    } catch (err) {
      console.error('Error fetching users:', err);
      setError('Error fetching users');
    } finally {
      setLoading(false);
    }
  };

  const handleApproval = async (userId, approve) => {
    try {
      console.log(`Updating approval status for user ${userId} to ${approve}`);
      await axios.put(`http://localhost:5000/api/admin/users/${userId}/approve`, 
        { approved: approve }
      );
      
      // Update local state instead of fetching again
      setUsers(prevUsers => 
        prevUsers.map(user => 
          user._id === userId ? { ...user, approved: approve } : user
        )
      );
    } catch (err) {
      console.error('Error updating approval:', err);
      setError('Error updating user approval');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="w-full max-w-4xl mx-auto my-8 bg-red-50">
        <CardContent className="p-6">
          <div className="text-red-500 text-center">
            <h3 className="text-lg font-semibold mb-2">Error</h3>
            <p>{error}</p>
            <Button 
              onClick={fetchUsers}
              variant="outline"
              size="sm"
              className="mt-4"
            >
              Retry
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-4xl mx-auto my-8">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Admin Dashboard</CardTitle>
        <Button 
          onClick={fetchUsers}
          variant="outline"
          size="sm"
        >
          Refresh
        </Button>
      </CardHeader>
      <CardContent>
        {users.length === 0 ? (
          <p className="text-center text-gray-500 py-4">No users found</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user._id}>
                  <TableCell>{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    <Badge variant={user.approved ? "success" : "warning"}>
                      {user.approved ? "Approved" : "Pending"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {!user.approved ? (
                      <Button 
                        onClick={() => handleApproval(user._id, true)} 
                        size="sm" 
                        className="mr-2"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" /> Approve
                      </Button>
                    ) : (
                      <Button 
                        onClick={() => handleApproval(user._id, false)} 
                        size="sm" 
                        variant="destructive"
                      >
                        <XCircle className="w-4 h-4 mr-2" /> Revoke
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
};

export default AdminDashboard;